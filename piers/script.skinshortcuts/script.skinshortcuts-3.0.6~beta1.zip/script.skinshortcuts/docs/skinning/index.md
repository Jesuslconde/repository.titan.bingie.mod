# Skinning Documentation

Integration guide for Skin Shortcuts.

[← Back to README](../../README.md)

---

## Getting Started

| Document | Description |
|----------|-------------|
| [Getting Started](getting-started.md) | Setup walkthrough and basic integration |
| [Starter Configuration](starter.md) | Copy/paste groupings and widget groups to build on |
| [File Overview](files.md) | Configuration file structure and loading |
| [Migrating from v2](../migration-v2-to-v3.md) | Porting a v2 skin to v3 |

## Configuration Files

| Document | Description |
|----------|-------------|
| [Menus](menus.md) | Menu structure, items, submenus, shortcut picker |
| [Widgets](widgets.md) | Widget definitions, picker groupings, per-item widget lists |
| [Backgrounds](backgrounds.md) | Background types and sources |
| [Properties](properties.md) | Custom property schemas and button mappings |
| [Templates](templates.md) | Output template system for include generation |
| [Views](views.md) | View locking configuration |
| [Retired Names](overrides.md) | Moving user selections when you rename or drop something |

## Reference

| Document | Description |
|----------|-------------|
| [Management Dialog](management-dialog.md) | Dialog controls, properties, window setup |
| [Built-in Properties](builtin-properties.md) | Properties available on menu items |
| [Conditions](conditions.md) | Condition syntax for properties and visibility |
| [Schema Reference](../schema.md) | Every element and attribute, across all config files |
| [Troubleshooting](troubleshooting.md) | Reading error notifications and enabling debug logging |
